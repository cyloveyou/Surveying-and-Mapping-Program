﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 空间数据分析3_David
{
    class Ellipse
    {
        public double sin_theta;
        public double cos_theta;
        public double SDEx;
        public double SDEy;
        public double X0;
        public double Y0;
    }
}
